/* task 3: race fixed with a mutex-protected critical section */
#include <stdio.h>
#include <pthread.h>

#define NUM_THREADS 4
#ifndef INCREMENTS_PER_THREAD
#define INCREMENTS_PER_THREAD 1000000
#endif

long counter = 0;
pthread_mutex_t counter_lock = PTHREAD_MUTEX_INITIALIZER;

void *worker(void *arg)
{
    (void)arg;
    for (int i = 0; i < INCREMENTS_PER_THREAD; i++) {
        pthread_mutex_lock(&counter_lock);   /* enter critical section */
        counter++;
        pthread_mutex_unlock(&counter_lock); /* leave critical section */
    }
    return NULL;
}

int main(void)
{
    pthread_t threads[NUM_THREADS];
    for (int i = 0; i < NUM_THREADS; i++)
        pthread_create(&threads[i], NULL, worker, NULL);
    for (int i = 0; i < NUM_THREADS; i++)
        pthread_join(threads[i], NULL);

    long expected = (long)NUM_THREADS * INCREMENTS_PER_THREAD;
    /* safe without the lock: pthread_join() makes every worker's writes visible */
    printf("Expected: %ld\n", expected);
    printf("Actual:   %ld\n", counter);
    printf("Correct:  %s\n", expected == counter ? "Y" : "N");
    return 0;
}
