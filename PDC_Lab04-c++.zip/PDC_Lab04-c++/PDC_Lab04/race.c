/* task 1: unsynchronized counter (shared-state hazard) */
#include <stdio.h>
#include <pthread.h>

#define NUM_THREADS 4
#ifndef INCREMENTS_PER_THREAD
#define INCREMENTS_PER_THREAD 1000000
#endif

long counter = 0; /* shared state */

void *worker(void *arg)
{
    (void)arg;
    for (int i = 0; i < INCREMENTS_PER_THREAD; i++) {
        counter++; /* unsynchronized read-modify-write */
    }
    return NULL;
}

int main(void)
{
    pthread_t threads[NUM_THREADS];
    for (int i = 0; i < NUM_THREADS; i++)
        pthread_create(&threads[i], NULL, worker, NULL);
    for (int i = 0; i < NUM_THREADS; i++)
        pthread_join(threads[i], NULL);

    long expected = (long)NUM_THREADS * INCREMENTS_PER_THREAD;
    printf("Expected: %ld\n", expected);
    printf("Actual:   %ld\n", counter);
    printf("Lost:     %ld\n", expected - counter);
    return 0;
}
