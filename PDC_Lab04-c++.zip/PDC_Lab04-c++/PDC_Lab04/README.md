# PDC Lab 04 - Concurrency Issues

Open this folder in VS Code (WSL window), then use the terminal:

```bash
make task1   # race.c, 10 runs
make task2   # tsan build of race.c, saves tsan_report.txt
make task3   # race_mutex.c, 10 runs + clean tsan check
make task4   # counter_bench.c (mutex / __sync / c11), 5 runs each + tsan check
make clean
```

Or: Terminal > Run Task... and pick a task.

If TSan fails with "unexpected memory mapping": `sudo sysctl vm.mmap_rnd_bits=28`
