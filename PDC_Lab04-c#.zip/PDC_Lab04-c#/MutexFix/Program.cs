﻿// Task 3: Fixing the race with a lock (critical section)
using System;
using System.Threading;

namespace MutexFix
{
    static class Program
    {
        const int NumThreads = 4;
        const int IncrementsPerThread = 1_000_000;

        static long counter = 0;                              // shared state
        static readonly object counterLock = new object();    // one shared lock object

        static void Worker()
        {
            for (int i = 0; i < IncrementsPerThread; i++)
            {
                lock (counterLock)   // critical section: only the increment
                {
                    counter++;
                }
            }
        }

        static void Main()
        {
            Thread[] threads = new Thread[NumThreads];
            for (int i = 0; i < NumThreads; i++)
            {
                threads[i] = new Thread(Worker);
                threads[i].Start();
            }
            for (int i = 0; i < NumThreads; i++)
            {
                threads[i].Join();
            }

            // Safe to read without the lock: Join() guarantees all writes
            // of the finished threads are visible here.
            long expected = (long)NumThreads * IncrementsPerThread;
            Console.WriteLine($"Expected: {expected}");
            Console.WriteLine($"Actual:   {counter}");
            Console.WriteLine($"Correct:  {(counter == expected ? "Y" : "N")}");
        }
    }
}